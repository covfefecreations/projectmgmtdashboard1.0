import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, CheckCircle2, Circle, Clock } from "lucide-react"

const milestones = [
  {
    id: 1,
    title: "Project Kickoff",
    date: "2025-01-15",
    description: "Initial team meeting and project planning session",
    status: "completed",
  },
  {
    id: 2,
    title: "Design Phase Complete",
    date: "2025-02-20",
    description: "All design mockups and wireframes approved by stakeholders",
    status: "completed",
  },
  {
    id: 3,
    title: "Development Sprint 1",
    date: "2025-03-10",
    description: "Homepage and core navigation components implemented",
    status: "in-progress",
  },
  {
    id: 4,
    title: "Development Sprint 2",
    date: "2025-03-31",
    description: "Product pages and responsive design implementation",
    status: "upcoming",
  },
  {
    id: 5,
    title: "Testing & QA",
    date: "2025-04-15",
    description: "Comprehensive testing across all devices and browsers",
    status: "upcoming",
  },
  {
    id: 6,
    title: "Launch",
    date: "2025-04-30",
    description: "Production deployment and go-live announcement",
    status: "upcoming",
  },
]

export function Timeline() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Project Timeline</CardTitle>
        <CardDescription>Key milestones and deliverables</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {milestones.map((milestone, index) => (
            <div key={milestone.id} className="flex gap-4">
              {/* Icon and Line */}
              <div className="relative flex flex-col items-center">
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                    milestone.status === "completed"
                      ? "bg-primary text-primary-foreground"
                      : milestone.status === "in-progress"
                        ? "bg-chart-2 text-white"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {milestone.status === "completed" ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : milestone.status === "in-progress" ? (
                    <Clock className="h-5 w-5" />
                  ) : (
                    <Circle className="h-5 w-5" />
                  )}
                </div>
                {index < milestones.length - 1 && <div className="h-full w-px bg-border" />}
              </div>

              {/* Content */}
              <Card className="flex-1 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                    <div className="space-y-1">
                      <h3 className="font-semibold text-foreground">{milestone.title}</h3>
                      <p className="text-sm text-muted-foreground">{milestone.description}</p>
                    </div>
                    <div className="flex flex-col items-start gap-2 sm:items-end">
                      <Badge
                        variant={
                          milestone.status === "completed"
                            ? "default"
                            : milestone.status === "in-progress"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {milestone.status === "completed"
                          ? "Completed"
                          : milestone.status === "in-progress"
                            ? "In Progress"
                            : "Upcoming"}
                      </Badge>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>
                          {new Date(milestone.date).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
